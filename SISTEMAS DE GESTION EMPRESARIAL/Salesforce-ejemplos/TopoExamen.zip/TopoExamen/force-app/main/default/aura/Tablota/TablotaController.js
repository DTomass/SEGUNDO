({
    myAction : function(component, event, helper) {

    },
    showPartida : function(component, event, helper) {
        var puntuacion = event.getParam("puntuacion");
        var list = component.get("v.partidasList")
        list.push({Puntuacion : puntuacion});
        component.set("v.partidasList", list );
    },
    clearList : function(component, event, helper) {
        component.set("v.partidasList", []);
    },
    clearItem : function(component, event, helper) {
        var ctarget = event.currentTarget;
        var index = ctarget.dataset.value;
        console.log(index);
        if(index){
            var list = component.get("v.partidasList");
            list.splice(index, 1);
            component.set("v.partidasList", list);
        }
    }
})
