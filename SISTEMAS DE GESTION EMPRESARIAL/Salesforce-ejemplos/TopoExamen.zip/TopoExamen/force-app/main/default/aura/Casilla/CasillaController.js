({
    myAction : function(component, event, helper) {

    },
    changeColorin : function(component, event, helper) {
        var td = component.getElement("td");
        td.style.backgroundColor = "red";
    },
    repite : function(component, event, helper) {
        var td = component.getElement("td");
        if (td.style.backgroundColor == "red") {
            td.style.backgroundColor = "white";
            var action = $A.get("e.c:iniTopo");
            action.setParams({"acierto": "si"});
            action.fire();
        }else{
            var action = $A.get("e.c:iniTopo");
            action.setParams({"acierto": "no"});
            action.fire();
        }
    }
})
