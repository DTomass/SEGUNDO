({
    myAction : function(component, event, helper) {

    },
    play : function(component, event, helper) {

        var action = $A.get("e.c:iniTopo");
        action.setParams({"acierto" : "no"})
        action.setParam("score", 0);
        action.fire();
    },
    stop : function(component, event, helper) {
        var actionFin = $A.get("e.c:finTopo");
        actionFin.fire();
    }
})
