({
    myAction : function(component, event, helper) {

    },
    iniciar : function(component, event, helper) {
        
        var div = component.find('score').getElement();
        if(div.style.visibility == "visible"){
            component.set("v.score", 0);
            div.style.visibility = "hidden";
        }else{
            var score = component.get("v.score");
        }
        var apexJuego = component.get("c.numAleatorio");
        var numTopos = component.find('hijo').length;
        var anterior = component.get("v.resultado");
        if(event.getParam("acierto") == "si"){
            component.set("v.score", score+1);
        }else if(event.getParam("acierto") == "no"){
            var hijos = component.find('hijo');
            for (let index = 0; index < hijos.length; index++) {
                var td = hijos[index].getElement("td");
                td.style.backgroundColor = "white";
            }
            component.set("v.score", 0);
        }
        console.log(event.getParam("acierto"));
        console.log(component.get("v.score"));
        apexJuego.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var resultado = response.getReturnValue();
                var hijo = component.find('hijo')[resultado];
                component.set("v.resultado", resultado);

                hijo.cambiarColor();
            }
        });
        apexJuego.setParams({numAnterior : anterior, numTopetes : numTopos});
        $A.enqueueAction(apexJuego);
    },
    finalizar : function(component, event, helper) {
        var score = component.get("v.score");
        var action = $A.get("e.c:savePartida");
        action.setParams({
            "puntuacion": score,
        });
        action.fire();
        component.set("v.score", score);
        var hijos = component.find('hijo');
        for (let index = 0; index < hijos.length; index++) {
            var td = hijos[index].getElement("td");
            td.style.backgroundColor = "white";
        }
        var div = component.find('score').getElement();
        div.style.visibility = "visible";
        
    }
})
