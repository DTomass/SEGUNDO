from multiprocessing import Lock
import threading
import time
import os

def get_size(files):
    for file in files:
        file_stats = os.stat(file)
        print(file_stats)
        print(f'File Size in Bytes is {file_stats.st_size}')
        print(f'File Size in MegaBytes is {file_stats.st_size / (1024 * 1024)}')
        counting(file)

def counting(filename):
    lock.acquire()
    txt_file = open(filename, "r")
  
    # Initialize three variables to count number of vowels,
    # lines and characters respectively
    vowel = 0
    line = 0
    character = 0
  
    # Make a vowels list so that we can
    # check whether the character is vowel or not
    vowels_list = ['a', 'e', 'i', 'o', 'u',
                   'A', 'E', 'I', 'O', 'U']
  
    # Iterate over the characters present in file
    for alpha in txt_file.read():
        
        # Checking if the current character is vowel or not
        if alpha in vowels_list:
            vowel += 1
              
        # Checking if the current character is
        # not vowel or new line character
        elif alpha not in vowels_list and alpha != "\n":
            character += 1
              
        # Checking if the current character
        # is new line character or not
        elif alpha == "\n":
            line += 1
  
    # Print the desired output on the console.
    print("Number of vowels in ", filename, " = ", vowel)
    print("New Lines in ", filename, " = ", line)
    print("Number of characters in ", filename, " = ", character)
    lock.release()


NUM_THREADS = int(input("Introduce el numero de hilos: "))
dirlist = os.listdir("C:/PruebaPSP")
lock = Lock()
for i in range(NUM_THREADS):
    t1 = threading.Thread(target=get_size, args=(dirlist,))
