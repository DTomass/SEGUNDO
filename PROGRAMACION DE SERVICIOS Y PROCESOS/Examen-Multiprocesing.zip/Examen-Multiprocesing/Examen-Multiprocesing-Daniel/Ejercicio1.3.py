from multiprocessing import Queue, Process
import random
import time
import math

q = Queue(10)
numconsumers = 2
numproducers = 4
def producer():
    """Productor"""
    numero = random.randint(10, 1000) #numero producido
    for i in range(0, 10, 1):
        q.join()
        q.put(numero)
        numero = random.randint(10, 1000)
        print(f"Se ha producido el numero{numero}")
    time.sleep(1)
def consumer(nums):
    n = mcd(nums[1], nums[2])
    print(f"El MCD de {nums[1]} y {nums[2]} es {n}")
    time.sleep(10)

def mcd(n1,n2):
    if n1<n2:
        i=n1
    else:
        i=n2
    while not (n1 % i == 0 and n2 % i == 0):
        i -= 1
    else:
        return i

if __name__ == "__main__":
         
    for i in range(numproducers):
        t2 = Process(producer)
    
    time.sleep(5)

    for i in range(numconsumers):
        t1 = Process(consumer, args=(q,))